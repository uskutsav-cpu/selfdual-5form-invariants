# Read this first

**Exact degree-ten invariants of a self-dual five-form in ten dimensions**

Draft for mentor review. Not submitted anywhere.

- Repository: `github.com/uskutsav-cpu/selfdual-5form-invariants`
- Branch: `publication/jhep-mentor-draft`
- Draft commit: `754d9c4bdb64187327d6a7cb7a5a07c17a1576aa`
- Certificates behind the draft: 27,
  hashed in `Ferko_certificate_manifest.json`

## What is in this directory

| file | what it is |
|---|---|
| `Ferko_mentor_review_draft.pdf` | the paper |
| `Ferko_review_guide.pdf` | **start here** — ten questions, in priority order |
| `Ferko_claim_ledger.pdf` | every claim mapped to the certificate behind it |
| `Ferko_figure_book.pdf` | all figures, full page, for reading away from the paper |
| `Ferko_reproduction_quickstart.pdf` | how to re-run everything from a clean clone |
| `Ferko_certificate_manifest.json` | hashes of every certificate the draft rests on |
| `Ferko_mentor_review_source.tar.gz` | LaTeX source; compiles on its own |
| `SHA256SUMS` | hashes of all of the above |

## What to read first

The review guide, section "The ten questions, in priority order". It gives, for
each question, the section and page, the equation, the artifact behind it, what
breaks if it is wrong, and wording we would accept instead.

If you have time for one question only, make it **Q4**, the G-10 stress-tensor
trace. The counterfactual collapses the headline result to zero.

## Which results are exact

Exact over the rationals, not modulo a prime:

- `dim_Q A10 = 14`, `dim_Q D10 = 11`, `dim_Q Q10 = 3`
- `dim_Q(B10 ∩ P10) = 1`, with the explicit integer identity

Exact modulo a prime, carried to characteristic zero by an integer minor:

- generic functional rank **at least 81**, via an explicit 81×81 minor

**Cited, not ours:** the analytic generic upper bound that closes rank 81. We do
not claim all 83 candidates are algebraically independent.

## What needs your judgement

The spinor conventions behind the orientation-fixed bridge; the real-form
statements; whether `D10` is the physically right object; whether the G-10
derivation holds in the formulation the source intends; how `Q10` should be
read; and the framing questions — credit for rank 81, the fairness of the
`B10 ∩ P10` discussion, the title, and what belongs in the body.

## Authorship and submission

**Authorship is not decided.** The title page says so. You are not named as an
author, and nothing in the draft implies you have approved the manuscript, the
results, authorship, credit, submission, or release of the repository.

**Nothing has been submitted.** Not to arXiv, not to JHEP. No DOI, no licence
and no release has been created. Those are decisions for after your review.
